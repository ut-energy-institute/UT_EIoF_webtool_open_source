library(testthat)
library(swagger)

test_check("swagger")
