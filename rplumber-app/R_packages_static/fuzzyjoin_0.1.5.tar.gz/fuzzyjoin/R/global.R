globalVariables(c("tbl_vars", "indices", "data", "i", "key", "value", "name", "newname"))
