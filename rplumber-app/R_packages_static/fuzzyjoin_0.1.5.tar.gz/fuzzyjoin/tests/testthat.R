library(testthat)
library(fuzzyjoin)

test_check("fuzzyjoin")
