void loadPathHack (char buf[256], void *addr);
