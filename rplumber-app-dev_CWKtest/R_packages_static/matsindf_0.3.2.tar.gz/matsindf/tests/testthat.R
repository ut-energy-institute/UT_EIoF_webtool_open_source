library(testthat)
library(matsindf)

test_check("matsindf")
