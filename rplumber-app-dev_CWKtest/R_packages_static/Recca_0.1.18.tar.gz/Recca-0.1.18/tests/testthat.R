library(testthat)

test_check("Recca")
