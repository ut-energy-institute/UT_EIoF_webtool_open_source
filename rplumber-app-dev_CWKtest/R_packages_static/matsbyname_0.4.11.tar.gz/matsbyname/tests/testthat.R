library(testthat)
library(matsbyname)

test_check("matsbyname")
